CMAKE_ANDROID_API_MIN
---------------------

.. versionadded:: 3.2

Default value for the :prop_tgt:`ANDROID_API_MIN` target property.
See that target property for additional information.
