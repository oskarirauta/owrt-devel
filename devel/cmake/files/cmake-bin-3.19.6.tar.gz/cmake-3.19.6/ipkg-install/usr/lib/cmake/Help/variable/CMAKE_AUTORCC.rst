CMAKE_AUTORCC
-------------

Whether to handle ``rcc`` automatically for Qt targets.

This variable is used to initialize the :prop_tgt:`AUTORCC` property on all
the targets.  See that target property for additional information.
