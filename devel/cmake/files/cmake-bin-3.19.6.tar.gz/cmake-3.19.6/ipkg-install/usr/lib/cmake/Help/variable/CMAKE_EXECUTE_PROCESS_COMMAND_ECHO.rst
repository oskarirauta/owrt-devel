CMAKE_EXECUTE_PROCESS_COMMAND_ECHO
----------------------------------

.. versionadded:: 3.15

If this variable is set to ``STDERR``, ``STDOUT`` or ``NONE`` then commands
in :command:`execute_process` calls will be printed to either stderr or
stdout or not at all.
