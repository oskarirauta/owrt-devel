CMAKE_HOST_APPLE
----------------

``True`` for Apple macOS operating systems.

Set to ``true`` when the host system is Apple macOS.
