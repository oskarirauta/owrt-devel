CMAKE_<LANG>_CPPCHECK
---------------------

.. versionadded:: 3.10

Default value for :prop_tgt:`<LANG>_CPPCHECK` target property. This variable
is used to initialize the property on each target as it is created.  This
is done only when ``<LANG>`` is ``C`` or ``CXX``.
