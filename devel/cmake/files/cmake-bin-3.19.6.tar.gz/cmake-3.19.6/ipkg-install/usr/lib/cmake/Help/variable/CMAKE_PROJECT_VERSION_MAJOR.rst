CMAKE_PROJECT_VERSION_MAJOR
---------------------------

.. versionadded:: 3.12

The major version of the top level project.

This variable holds the major version of the project as specified in the top
level CMakeLists.txt file by a :command:`project` command. Please see
:variable:`CMAKE_PROJECT_VERSION` documentation for the behavior when
multiple :command:`project` commands are used in the sources.
