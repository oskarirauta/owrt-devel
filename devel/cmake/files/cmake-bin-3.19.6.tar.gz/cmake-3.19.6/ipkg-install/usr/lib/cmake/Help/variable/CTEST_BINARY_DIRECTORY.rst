CTEST_BINARY_DIRECTORY
----------------------

.. versionadded:: 3.1

Specify the CTest ``BuildDirectory`` setting
in a :manual:`ctest(1)` dashboard client script.
