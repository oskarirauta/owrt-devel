CTEST_BUILD_COMMAND
-------------------

.. versionadded:: 3.1

Specify the CTest ``MakeCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
