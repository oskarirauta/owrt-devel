CTEST_DROP_LOCATION
-------------------

.. versionadded:: 3.1

Specify the CTest ``DropLocation`` setting
in a :manual:`ctest(1)` dashboard client script.
