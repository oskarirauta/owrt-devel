CTEST_P4_CLIENT
---------------

.. versionadded:: 3.1

Specify the CTest ``P4Client`` setting
in a :manual:`ctest(1)` dashboard client script.
