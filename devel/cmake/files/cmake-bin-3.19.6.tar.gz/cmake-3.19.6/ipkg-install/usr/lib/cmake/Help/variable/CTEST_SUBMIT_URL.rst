CTEST_SUBMIT_URL
----------------

.. versionadded:: 3.14

Specify the CTest ``SubmitURL`` setting
in a :manual:`ctest(1)` dashboard client script.
