CTEST_SVN_COMMAND
-----------------

.. versionadded:: 3.1

Specify the CTest ``SVNCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
