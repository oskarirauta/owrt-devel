CTEST_UPDATE_VERSION_ONLY
-------------------------

.. versionadded:: 3.1

Specify the CTest :ref:`UpdateVersionOnly <UpdateVersionOnly>` setting
in a :manual:`ctest(1)` dashboard client script.
