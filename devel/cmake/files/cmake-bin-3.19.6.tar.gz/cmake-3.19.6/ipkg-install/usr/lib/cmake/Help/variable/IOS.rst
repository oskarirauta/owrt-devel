IOS
---

.. versionadded:: 3.14

Set to ``1`` when the target system (:variable:`CMAKE_SYSTEM_NAME`) is ``iOS``.
