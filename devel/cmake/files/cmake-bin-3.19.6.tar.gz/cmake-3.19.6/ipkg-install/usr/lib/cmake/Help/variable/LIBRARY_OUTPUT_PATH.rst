LIBRARY_OUTPUT_PATH
-------------------

Old library location variable.

The target properties :prop_tgt:`ARCHIVE_OUTPUT_DIRECTORY`,
:prop_tgt:`LIBRARY_OUTPUT_DIRECTORY`, and :prop_tgt:`RUNTIME_OUTPUT_DIRECTORY`
supersede this variable for a target if they are set.  Library targets are
otherwise placed in this directory.
