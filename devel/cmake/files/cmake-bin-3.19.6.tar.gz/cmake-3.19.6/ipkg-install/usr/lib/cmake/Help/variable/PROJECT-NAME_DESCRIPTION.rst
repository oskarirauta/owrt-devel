<PROJECT-NAME>_DESCRIPTION
--------------------------

.. versionadded:: 3.12

Value given to the ``DESCRIPTION`` option of the most recent call to the
:command:`project` command with project name ``<PROJECT-NAME>``, if any.
