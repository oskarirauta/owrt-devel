<PROJECT-NAME>_SOURCE_DIR
-------------------------

Top level source directory for the named project.

A variable is created with the name used in the :command:`project` command,
and is the source directory for the project.  This can be useful when
:command:`add_subdirectory` is used to connect several projects.
