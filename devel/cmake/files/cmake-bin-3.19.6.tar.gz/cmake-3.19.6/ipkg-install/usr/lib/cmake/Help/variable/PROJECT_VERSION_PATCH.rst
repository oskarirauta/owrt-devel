PROJECT_VERSION_PATCH
---------------------

Third version number component of the :variable:`PROJECT_VERSION`
variable as set by the :command:`project` command.
