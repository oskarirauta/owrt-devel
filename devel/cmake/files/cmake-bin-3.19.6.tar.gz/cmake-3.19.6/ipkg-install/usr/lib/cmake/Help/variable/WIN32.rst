WIN32
-----

Set to ``True`` when the target system is Windows, including Win64.
